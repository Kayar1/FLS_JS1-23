

const calc = require ('./main');


    console.log(calc(12, 4, '+'));
    console.log(calc(1, 4, '-'));
    console.log(calc(12, 5, '/', 1));
    console.log(calc(1.2, 3, '*', 1));

    //16
    //-3
    //2.4
    //3.6

    test('+', () => {
        expect(calc(12, 4, '+', -999999)).toBe(16);
    })
    test('-', () => {
        expect(calc(1, 4, '-', -999999)).toBe(-3);
    })
    test('/', () => {
        expect(calc(12, 5, '/', -999999)).toBe(12 / 5);
    })
    test('*', () => {
        expect(calc(1.2, 3, '*', -999999)).toBe(1.2 * 3);
    })