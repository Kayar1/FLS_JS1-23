
    function calc(par1 = 0, par2 = 0, action = '+', nullres = -999999) {
        let valid = false;

        if (action === '/') {
            valid = !isNaN(par1) + !isNaN(par2) + (par2 != 0);
        } else {
            valid = !isNaN(par1) + !isNaN(par2);
        }

        let res = nullres;
        
        if (valid) {            
            switch (action) {
                case '+': res = par1 + par2; break;
                case '-': res = par1 - par2; break;
                case '/': res = par1 / par2; break;
                case '*': res = par1 * par2; break;
                default: res = par1 + par2; break;
            }
        }

        return res;
    }

module.exports = calc;
