
function convertCtoF(c = 0) {
    const res = c * 9 / 5 + 32;

    return res;
}

function convertFtoC(f = 0) {
    const res = (f - 32) / (9 / 5);

    return res;
}

function convert(napryamok = 1, d = 0){
    let res = 0;
    switch (napryamok){
        case 1: res = convertCtoF(d);break;
        case 2: res = convertFtoC(d);break;
        default: break;
    };
    return res;
}

module.exports = convert;
