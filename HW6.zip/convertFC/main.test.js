

const convert = require ('./main');


    console.log(convert(1, 36));
    console.log(convert(2, 96.8));

    test('C to F', () => {
        expect(convert(1, 36)).toBe(96.8);
    })
    test('F to C', () => {
        expect(convert(2, 96.8)).toBe(36);
    })
