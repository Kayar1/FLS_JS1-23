
function DNA(base = '') {
    const getDNA = cell => {
        let res = '';
        switch (cell) {
            case 'A': res = 'T'; break;
            case 'T': res = 'A'; break;
            case 'C': res = 'G'; break;
            case 'G': res = 'C'; break;
            default: res = '';
        }

        return res;
    }

    let res = '';

    for (i = 0; i < base.length; i++) {
        res += getDNA(base[i]);
    }
    return res;
}

module.exports = DNA;
