

const DNA = require ('./main');


 
    test('+', () => {
        expect(DNA('ATTGC')).toBe('TAACG');
    })
    test('-', () => {
        expect(DNA('GTAT')).toBe('CATA');
    })
 