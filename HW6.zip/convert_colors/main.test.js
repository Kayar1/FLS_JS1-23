

const convert = require ('./main');



    test('RGB to HEX', () => {
        expect(convert(1, 17, 34, 51)).toBe('RGB (17, 34, 51) = HEX #112233');
    })
    test('RGB to HEX', () => {
        expect(convert(1, 243, 228, 160)).toBe('RGB (243, 228, 160) = HEX #f3e4a0');
    })
    test('HEX to RGB', () => {
        expect(convert(2,0,0,0,0xf3e4a0)).toBe('HEX f3e4a0 = RGB(243, 228, 160)');
    })
    test('HEX to RGB', () => {
        expect(convert(2,0,0,0,0x112233)).toBe('HEX 112233 = RGB(17, 34, 51)');
    })