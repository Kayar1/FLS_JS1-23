
function convertRGBtoHEX(r = 0, g = 0, b = 0) {
    const res = `RGB (${r}, ${g}, ${b}) = HEX #` +
        `${r.toString(16).padStart(2, '0')}` +
        `${g.toString(16).padStart(2, '0')}` +
        `${b.toString(16).padStart(2, '0')}`;
    return res;
}

function convertHEXtoRGB(hex = 0x00) {
    let str = '';
    let temp = 0;

    if (hex > 0) {
        str = hex.toString(16).padStart(6, '0');
        temp = hex;
    } else {
        str = hex;
        temp = parseInt(hex.split('#')[1], 16);
    }
    const r = (temp >> 16) & 255;
    const g = (temp >> 8) & 255;
    const b = temp & 255;
    return `HEX ${str} = RGB(${r}, ${g}, ${b})`;
}

function convert(n = 1, r = 0, g = 0, b = 0, hex = 0x00){
    let res = '';
    switch (n){
        case 1: res = convertRGBtoHEX(r, g, b);break;
        case 2: res = convertHEXtoRGB(hex);break;
        default: break;
    }
    return res;
}

module.exports = convert;
